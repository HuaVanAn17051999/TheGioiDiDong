﻿
$(document).ready(function () {

    alert('xoa gio hang');
});