﻿

$(document).ready(function () {
    $(".logout").hide();
    $('.account').on('click', function () {
        $(".logout").toggle();
    });

});